#ifndef __DEFINE_HPP__
#define __DEFINE_HPP__

#include <vector>
#include <stack>
#include <string>
#include "caffe/util/Eigen/Dense"

using namespace std;
using namespace Eigen;
// Size (in bytes) for all I/O buffers
#define CHUNK (1<<18)

// Tensor dimensionality, ranks and sizes. They are only set, never modified
uint32_t n;
size_t size;
  
double datanorm, sse, lim;
double datamin = numeric_limits < double >::max();
double datamax = numeric_limits < double >::min();

vector<uint8_t> chunk_ids;

vector<uint32_t> r;
vector<uint32_t> s;

vector<size_t> rprod;
vector<size_t> sprod;

vector<double> core;
vector<double> core_t;
vector<double> minimums;
vector<double> maximums;

vector<MatrixXd> Us;
vector<MatrixXd> Us_t;

vector< vector<uint8_t> > Us_q;

vector< pair<double,size_t> > sorting;


double min(double a, double b) {
    return (a < b) ? a : b;
}

double max(double a, double b) {
    return (a > b) ? a : b;
}

size_t factor(Block<MatrixXd, -1, -1, true> U, vector<uint8_t>& U_q, MatrixXd& U_t) {
  double maximum = U.array().abs().maxCoeff();
  U_t = MatrixXd(U.rows(), U.cols());
  size_t qbits = 0;
  for (uint32_t j = 0; j < U.cols(); ++j) {
    for (uint32_t i = 0; i < U.rows(); ++i){
        uint8_t q = U_q[j];
// /*
        // quantization
        if (q > 0) {
            q = min(32, q + 2);
            uint64_t to_write;
            to_write = min(((1UL << q) - 1), (uint64_t) roundl(abs(U(i, j)) / maximum * ((1UL << q) - 1)));
            if (U(i, j) < 0){
                to_write |=  1UL << q;                  // The sign is the most significant bit
            }
            
            qbits += q;

       // de-quantization
            uint64_t quant = to_write;
            uint8_t sign = (quant >> q) & 1UL;          // Read the sign bit
            quant &= ~(1UL << q);                       // Put the sign bit to zero
            U_t(i, j) = -(2 * sign - 1) / ((1UL << q) - double (1)) *maximum * double (quant);
        } else
             U_t(i, j) = 0;          
    }
  }
// */
/*
    U_t(i, j) = U(i, j);
}
}
*/
    return qbits;
}
#endif // DEFINE_HPP

