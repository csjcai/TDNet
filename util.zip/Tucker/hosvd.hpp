#ifndef __HOSVD_HPP__
#define __HOSVD_HPP__

#include "caffe/util/Eigen/Dense"

using namespace std;
using namespace Eigen;

// Projects an unfolded core M into M_proj using the transformation matrix U.
// U is an output parameter and is computed as the HOSVD of the tensor (left singular vectors of M) and M is compressed using U.transpose().
void project(MatrixXd& M, MatrixXd& U, MatrixXd& M_proj)
{
    SelfAdjointEigenSolver < MatrixXd > es(M * M.transpose()); // M*M^T is symmetric -> faster eigenvalue computation
    VectorXd eigenvalues = es.eigenvalues().real();
    MatrixXd U_unsorted = es.eigenvectors().real();
    uint32_t s = M.rows();
    U = MatrixXd(s, s);
    // We sort the (eigenvalue, eigenvector) pairs in descending order
    vector < pair<double, uint32_t> > eigenvalues_sorted(s);
    for (uint32_t i = 0; i < s; ++i)
        eigenvalues_sorted[i] = pair < double, uint32_t > (-eigenvalues(i), i);
    sort(eigenvalues_sorted.begin(), eigenvalues_sorted.end());
    for (uint32_t i = 0; i < s; ++i)
        U.col(i) = U_unsorted.col(eigenvalues_sorted[i].second);
    M_proj = U.transpose() * M;
}

// U is an input parameter and M is decompressed using U (sliced as appropriate)
void unproject(MatrixXd& M, MatrixXd& U, MatrixXd& M_proj) {
        M_proj = U * M;
}

// Reads a tensor in the buffer data of size s, and compresses it.
// The factor matrices are output parameters
void hosvd_compress(vector<double>& data, vector<MatrixXd>& Us)
{
    uint32_t n = s.size();

    // First unfolding: special case (elements are already arranged as we want)
    MatrixXd M = MatrixXd::Map(data.data(), s[0], sprod[n]/s[0]);
    MatrixXd M_proj;
    project(M, Us[0], M_proj);

    // Remaining unfoldings: all of them go matrix -> matrix
    // Input: matrix of size s[dim-1] x (s[0] * ... * s[dim-2] * s[dim] * ... * s[N])
    // Output: matrix of size s[dim] x (s[0] * ... * s[dim-1] * s[dim+1] * ... * s[N])
    for (uint8_t dim = 1; dim < n; ++dim) {
        M = MatrixXd(s[dim], sprod[n]/s[dim]); // dim-th factor matrix
        for (int64_t j = 0; j < M_proj.cols(); ++j) {
            uint32_t write_i = (j/sprod[dim-1]) % s[dim];
            size_t base_write_j = j%sprod[dim-1] + j/(sprod[dim-1]*s[dim])*sprod[dim];
            for (int32_t i = 0; i < M_proj.rows(); ++i)
                M(write_i, base_write_j + i*sprod[dim-1]) = M_proj(i, j);
        }
        project(M, Us[dim], M_proj);
    }

    // We fold back from matrix into ND tensor
    for (uint32_t i = 0; i < s[n-1]; i++)
        for (size_t j = 0; j < sprod[n-1]; j++)
            data[i*sprod[n-1] + j] = M_proj(i, j);
}

// Reads a tensor in the buffer data of size s, and decompresses it in-place
void hosvd_decompress(vector<double>& data, vector<MatrixXd>& Us)
{
    if (rprod[n] == 0) { // Extreme case: 0 ranks
        data = vector<double> (sprod[n], 0); // Produce a 0 reconstruction of the expected size, and leave
        return;
    }

    // First unfolding: special case (elements are already arranged as we want)
    MatrixXd M = MatrixXd::Map(data.data(), r[0], rprod[n]/r[0]);
    MatrixXd M_proj;
    unproject(M, Us[0], M_proj);

    // Remaining unfoldings: all of them go matrix -> matrix
    // Input: matrix of size s[dim-1] x (s[0] * ... * s[dim-2] * s[dim] * ... * s[N])
    // Output: matrix of size s[dim] x (s[0] * ... * s[dim-1] * s[dim+1] * ... * s[N])
    for (uint8_t dim = 1; dim < n; ++dim) {
        M = MatrixXd(r[dim], sprod[dim]*rprod[n]/rprod[dim+1]); // dim-th factor matrix
        for (int64_t j = 0; j < M_proj.cols(); ++j) {
            uint32_t write_i = (j/sprod[dim-1]) % r[dim];
            size_t base_write_j = j%sprod[dim-1] + j/(sprod[dim-1]*r[dim])*sprod[dim];
            for (int32_t i = 0; i < M_proj.rows(); ++i)
                M(write_i, base_write_j + i*sprod[dim-1]) = M_proj(i, j);
        }
        unproject(M, Us[dim], M_proj);
    }

    // We fold back from matrix into ND tensor
    data.resize(sprod[n]);
    data.shrink_to_fit();
    for (size_t i = 0; i < sprod[n]; i++)
        data[i] = M_proj(i/sprod[n-1], i%sprod[n-1]);
}

#endif // HOSVD_HPP

