#ifndef __CODEBOOK_HPP__
#define __CODEBOOK_HPP__

#include <iostream>
#include <fstream>
#include <queue>
#include <map>
#include <iterator>
#include <algorithm>
#include <cstring>

using namespace std;

typedef std::vector<bool> HuffCode;
typedef std::map<size_t, uint64_t> HuffCodeMap;

class INode {
public:
    const size_t
    f;
    virtual ~ INode() {
    } protected:
    INode(size_t f):f(f) {
    }
};

class InternalNode:public INode {
public:
    INode * const
    left;
    INode *const
    right;

    InternalNode(INode * c0, INode * c1):INode(c0->f + c1->f), left(c0), right(c1) {
    } ~InternalNode() {
        delete left;
        delete right;
    }
};

class LeafNode:public INode {
public:
    const size_t
    c;
    LeafNode(size_t f, size_t c):INode(f), c(c) {
    }};

struct NodeCmp {
    bool operator  () (const INode * lhs, const INode * rhs) const {
        return lhs->f > rhs->f;
    }};

INode *BuildTree(std::map < size_t, uint32_t >&frequencies)
{
    std::priority_queue < INode *, std::vector < INode * >, NodeCmp > trees;

    for (std::map<size_t, uint32_t>::iterator it = frequencies.begin(); it != frequencies.end(); ++it) {
        trees.push(new LeafNode(it->second, (uint32_t) it->first));
    }
    while (trees.size() > 1) {
        INode *childR = trees.top();
        trees.pop();

        INode *childL = trees.top();
        trees.pop();

        INode *parent = new InternalNode(childR, childL);
        trees.push(parent);
    }
    return trees.top();
}

void GenerateCodes(const INode * node, const HuffCode & prefix, HuffCodeMap & outCodes, std::map<size_t, uint8_t>& code_lens)
{
    if (const LeafNode * lf = dynamic_cast < const LeafNode * >(node)) {
        uint64_t binary = 0;
        for (int i = prefix.size()-1; i >= 0; --i)
            binary |= prefix[prefix.size()-1-i] << i;
        outCodes[lf->c] = binary;
        code_lens[lf->c] = prefix.size();
    } else if (const InternalNode * in = dynamic_cast < const InternalNode * >(node)) {
        HuffCode leftPrefix = prefix;
        leftPrefix.push_back(false);
        GenerateCodes(in->left, leftPrefix, outCodes, code_lens);

        HuffCode rightPrefix = prefix;
        rightPrefix.push_back(true);
        GenerateCodes(in->right, rightPrefix, outCodes, code_lens);
    }
}

size_t codebook(vector<size_t>& rle) {

    std::map<size_t, uint8_t> code_lens;
    std::map<size_t, uint32_t> frequencies;
    for (size_t i = 0; i < rle.size(); ++i)
        ++frequencies[rle[i]];

    INode *root = BuildTree(frequencies);

    HuffCodeMap codes;
    GenerateCodes(root, HuffCode(), codes, code_lens);
    delete root;

    if (frequencies.size() == 1) { 
        codes[frequencies.begin()->first] = 0;
        code_lens[frequencies.begin()->first] = 1;
    }

    size_t hbits = 0;
    for (HuffCodeMap::const_iterator it = codes.begin(); it != codes.end(); ++it) {

        uint64_t key = it->first; 
        uint8_t key_len = 0;
        uint64_t key_copy = key;
        while (key_copy) {
            key_copy >>= 1;
            key_len++;
        }
        key_len = max(1, key_len); 
        hbits += 6 + key_len + 6 + code_lens[key] + code_lens[key]*frequencies[key];
    }

    return hbits;
}

#endif // __CODEBOOK_HPP__

